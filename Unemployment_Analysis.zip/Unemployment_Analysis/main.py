import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings

warnings.filterwarnings('ignore')

print("--- 1. Loading & Cleaning Data ---")
# Dataset load karein
df = pd.read_csv('Unemployment in India.csv')

# Clean column names
df.columns = df.columns.str.strip()
df.dropna(inplace=True)

# Rename columns for clarity
df.rename(columns={
    'Region': 'State',
    'Estimated Unemployment Rate (%)': 'Unemployment_Rate',
    'Estimated Employed': 'Employed',
    'Estimated Labour Participation Rate (%)': 'Labour_Participation_Rate'
}, inplace=True)

# Convert Date column
df['Date'] = pd.to_datetime(df['Date'].str.strip(), format='%d-%m-%Y')

# COVID Lockdown Label
df['COVID_Period'] = np.where(
    df['Date'] >= '2020-03-31', 'Post-COVID / Lockdown', 'Pre-COVID')

print("Data Cleaning Finished Successfully!")
print(df.head())

print("\n--- 2. Summary Statistics ---")
print(df[['Unemployment_Rate', 'Employed', 'Labour_Participation_Rate']].describe())

print("\n--- 3. Generating Graphs ---")
sns.set_theme(style="whitegrid")

# Graph 1: Trend Over Time
plt.figure(figsize=(10, 5))
sns.lineplot(data=df, x='Date', y='Unemployment_Rate', marker='o')
plt.axvline(pd.to_datetime('2020-03-24'), color='red',
            linestyle='--', label='Lockdown Start')
plt.title('Unemployment Rate Trend (Pre vs Post COVID-19)')
plt.xlabel('Date')
plt.ylabel('Unemployment Rate (%)')
plt.legend()
plt.tight_layout()
plt.show()

# Graph 2: Pre vs Post COVID Comparison
plt.figure(figsize=(6, 4))
sns.boxplot(data=df, x='COVID_Period', y='Unemployment_Rate', palette='Set2')
plt.title('Unemployment Rate: Pre-COVID vs Post-COVID')
plt.tight_layout()
plt.show()
